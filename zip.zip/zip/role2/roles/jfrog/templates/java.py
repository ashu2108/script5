import os
import sys
os.system('echo JAVA_HOME="/usr/lib/jvm/java-8-openjdk-amd64/jre/bin/java" >> /etc/environment')
os.system('source /etc/environment')
